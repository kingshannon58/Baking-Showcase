My baking showcase
------------------
Just showing all the things I have baked on a slideshow-type page

A [Pen](https://codepen.io/shking/pen/dEXxRR) by [Shannon Bryan](https://codepen.io/shking) on [CodePen](https://codepen.io).

[License](https://codepen.io/license/pen/dEXxRR).